package Biblioteca;

public class Socio extends Persona {
	

	public Socio(String nombre, String apellidos, String dni) {
		
        super(nombre, apellidos, dni);
        
    }
	
}
